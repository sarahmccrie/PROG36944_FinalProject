﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FinalProject_ERMS.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Role is required.")]
        public string Role { get; set; }

        public ICollection<Project> ManagedProjects { get; set; }
        public ICollection<TaskItem> AssignedTasks { get; set; }
    }
}